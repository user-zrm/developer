package com.martinrz.contact.service;

public interface ContactService {

}
