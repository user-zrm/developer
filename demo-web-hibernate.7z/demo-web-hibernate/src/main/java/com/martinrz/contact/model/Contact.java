package com.martinrz.contact.model;

public class Contact {

}
