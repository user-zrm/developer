package com.martinrz.contact.controller;

public class ContactController {

}
