package com.martinrz.contact.dao;

public interface ContactDAO {

}
