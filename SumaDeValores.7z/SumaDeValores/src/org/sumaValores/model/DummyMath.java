package org.sumaValores.model;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class DummyMath {
	
	private ArrayList<Integer> original;
	
	private ArrayList<String> original2;
	
	private HashSet<Integer>  original3;
	
	private  List<String> arraylista2;
	
	private Set<String> set;
	
	private ArrayList<Integer> hashset;
	
	private ArrayList<Integer> numeros ;
	

	/**
	 * @return the numeros
	 */
	public ArrayList<Integer> getNumeros() {
		return numeros;
	}
	/**
	 * @param numeros the numeros to set
	 */
	public void setNumeros(ArrayList<Integer> numeros) {
		this.numeros = numeros;
	}
	/**
	 * @return the original
	 */
	
	public ArrayList<Integer> getOriginal() {
		return original;
	}
	/**
	 * @param original the original to set
	 */
	
	public void setOriginal(ArrayList<Integer> original) {
		this.original = original;
	}
	
	/**
	 * @return the original2
	 */
	public List<String> getOriginal2() {
		return original2;
	}
	/**
	 * @param original2 the original2 to set
	 */
	public void setOriginal2(ArrayList<String> original2) {
		this.original2 = original2;
	}


	/**
	 * @return the original3
	 */
	public HashSet<Integer> getOriginal3() {
		return original3;
	}

	/**
	 * @param original3 the original3 to set
	 */
	public void setOriginal3(HashSet<Integer> original3) {
		this.original3 = original3;
	}


	

	public DummyMath(ArrayList<Integer> original) {
		super();
		this.original = original;
	}

	public DummyMath() {}
	
	
	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		
		return super.hashCode();
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		// TODO Auto-generated method stub
		return super.equals(obj);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return super.toString();
	}
	
	}
	
	
	
	
	


