package org.sumaValores.app;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.sumaValores.model.DummyMath;
import org.sumaValores.service.impl.DummyMathImpl;

public class AppMain {
	
	
	
	private static ArrayList<Integer> original = new ArrayList<>();
	private static ArrayList<Integer> olist = new ArrayList<>();
	private static ArrayList<String> original2 = new ArrayList<>();
    private	static List<String> lista2 = new ArrayList<>();
	public static HashSet<String> set = new HashSet<>();
	public static Set<String> set1 = new HashSet<>();
	private static List<String> arraylista2 = new ArrayList<>();
	private static ArrayList<Integer> hashset = new ArrayList<>();
	public static void main(String[] args ) {
		
		
		 /*Set<Integer> hashset = new HashSet<Integer>();
		    hashset.add(11);
		    hashset.add(43);
		    hashset.add(56);
		    hashset.add(3049);
		    hashset.add(3);
		    hashset.add(21);
		    hashset.add(44);
		    hashset.add(67);
		    hashset.add(46);
		    hashset.add(88);
		    hashset.add(44);
		    hashset.add(21);
		    hashset.add(46);
		    hashset.add(108);
		    
		  
		    List<Integer> listv = new ArrayList<Integer>(hashset);
		    System.out.println(listv.toString());
*/

		DummyMathImpl dummyMathImpl = new DummyMathImpl();
		dummyMathImpl.add2(original, olist);
		dummyMathImpl.deleteDuplicates (original2,set, arraylista2);
		dummyMathImpl.deletePairs(original, hashset);
		dummyMathImpl.addRamdon(original, original, 0,0, 0);
	}

}
