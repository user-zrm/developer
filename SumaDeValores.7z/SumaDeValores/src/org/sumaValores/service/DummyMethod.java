package org.sumaValores.service;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public interface DummyMethod {
	
	public ArrayList<Integer> add2(ArrayList<Integer> original,ArrayList<Integer> olis);
	
	public ArrayList<String> deleteDuplicates(ArrayList<String> original2,HashSet<String> original3,List<String> arraylista2 );
		
	public ArrayList<Integer> deletePairs(ArrayList<Integer> original, ArrayList<Integer> hashset);
	
	public ArrayList<Integer> addRamdon(ArrayList<Integer> original,ArrayList<Integer> numeros,int desde,int hasta, int tam);

}
