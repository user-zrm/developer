package org.sumaValores.service.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.Set;

import org.sumaValores.service.DummyMethod;

public class DummyMathImpl implements DummyMethod {

	@Override
	public ArrayList<Integer> add2(ArrayList<Integer> original, ArrayList<Integer> olis) {
		
		original = new ArrayList<>();
		
		original.add(new Integer(11));
		original.add(new Integer(43));
		original.add(new Integer(56));
		original.add(new Integer(3049));
		original.add(new Integer(3));
		original.add(new Integer(21));
		original.add(new Integer(44));
		original.add(new Integer(67 ));
		original.add(new Integer(46));
		original.add(new Integer(88));
		original.add(new Integer(44));
		original.add(new Integer(21));
		original.add(new Integer(46));
		original.add(new Integer(108));
		
		
		for (Integer olist1 : original) {
			String s = String.valueOf(olist1);
			System.out.println("Valores del Array = " + s);
				
		}
		
		System.out.println("+-----------------------------------------+");
		
		for (Integer olist1 : original) {
			String s = String.valueOf(olist1 + 2);
			System.out.println("Valor Incrementado en 2 unidades = " + s);
				
		}
		  
		return original;
		
	}

	@Override
	public ArrayList<String> deleteDuplicates(ArrayList<String> original2,HashSet<String> original3,List<String> arraylista2 ) {
		
		
        original2 = new ArrayList<>();	
       
        
        
		original2.add("11");
		original2.add("43");
		original2.add("56");
		original2.add("3049");
		original2.add("3");
		original2.add("21");
		original2.add("44");
		original2.add("67");
		original2.add("46");
		original2.add("88");
		original2.add("44");
		original2.add("21");
		original2.add("46");
		original2.add("108");
		/*
		HashSet<String> hashSet = new HashSet<>(original2);
		Set<String> set1 = new HashSet<String>(hashSet);*/
		
		/*List<String> arraylista = new ArrayList<>(hashSet);
		arraylista.addAll(hashSet);*/
		
	/*	ArrayList<String> lista2 = new ArrayList<String>(hashSet);*/
		/*List<String> lista2 = new ArrayList<>(); */
		/*Set<String>  set1 =	new HashSet<>(hashSet);
		  set1.addAll(set1);
		  */
		/*ArrayList<String> lista = new ArrayList<String> ();*/
	       Set<String>  set1 = new HashSet<String>(original2);
	       set1.addAll(original2);
	       original2.clear();
	       original2.addAll(set1);
		
		
		/*lista2.addAll(lista2);*/
	       
	   
		
		for (Object item : original2) {
			  
	
			 
			 /*set1.remove(item);*/
			System.out.println("Elimina Numeros   Duplicados " + item.toString());
			
		}
		
		
		return (ArrayList<String>) original2;
	}

	@Override
	public ArrayList<Integer> deletePairs(ArrayList<Integer> original, ArrayList<Integer> hashset) {

		int[] array = { 11, 43, 56, 3049, 3, 21, 44, 67, 46, 88, 44, 21, 46, 108 };
		
		try {

			for (int i = 0; i < array.length; i++) {

				if ((array[i] % 2) == 0) {

					original = new ArrayList<Integer>();
					
					
					
					  List<Integer> lista = new ArrayList<Integer>(original);
				      lista.add(array[i]);
					  Collections.sort(lista);
					  Set<Integer> hash_Set = new HashSet<Integer>(lista);

					/* para recorrer las posiciones del ArrayList */
					Iterator<Integer> it = hash_Set.iterator();
					while (it.hasNext()) {
						Object elemento = it.next();
						
						if (elemento.equals(hash_Set)) {
														 
							 hash_Set.add(array[i]);
							
							 System.out.println(" numero repetido" + hash_Set + " ");
							/*List<Integer> listv = new ArrayList<Integer>(hash_Set);*/

							/*original.addAll(listv);*/
						
							/*System.out.print("  N�meros Par : " + hash_Set + " ");*/

						} else {
							System.out.println( "*** numero Par de la Lista" + hash_Set.toString()  + hash_Set.removeAll(hash_Set) + "..Eliminado"  );
						    
							
						
						}
																		
						original.clear();
						original.addAll(hash_Set);
						
						
						
						
					}  // end while()
				  }  // end if
    
			   }  // end for 
			
			for (Integer nimpar : original) {
				System.out.println("Lista :" + nimpar );
				
			}
			
			
			}	
			catch (NullPointerException e) {
				
				System.out.println("Exception thrown : " + e);

		}   catch (IllegalArgumentException e) { 

			 System.out.println("Exception thrown : " + e); 
           
     } 

		 
		return original;  
		

	}

	
	private static int tam = inicializaCampo();
	 
    private static int inicializaCampo() {
        return 5;
    }
	
	
	public ArrayList<Integer> addRamdon(ArrayList<Integer> original,ArrayList<Integer> numeros, int desde,int hasta, int tam) {

		original = new ArrayList<>();

		original.add(new Integer(11));
		original.add(new Integer(43));
		original.add(new Integer(56));
		original.add(new Integer(3049));
		original.add(new Integer(3));
		original.add(new Integer(21));
		original.add(new Integer(44));
		original.add(new Integer(67));
		original.add(new Integer(46));
		original.add(new Integer(88));
		original.add(new Integer(44));
		original.add(new Integer(21));
		original.add(new Integer(46));
		original.add(new Integer(108));
           
		
		ArrayList<Integer> numerosR = new ArrayList<Integer>();
		numerosR.addAll(original); 
		desde = 1000;
		hasta = 3000;
		Random rnd = new Random();
		Integer n = 0;
		for (int i = 0; i < numerosR.size(); i++) {
			do { 
				n = rnd.nextInt(hasta - desde + 1) + desde;
								
			} while (comprobarSiContiene(numerosR, i, n));
			
				if (numerosR.size() <= 19) {
					numerosR.add(n);
					original.addAll(numerosR);
					
					}else {
				       return null;	
					}
				for (Integer nramdon : original) {
					
					System.out.println(" Numeros ramdom " + nramdon.toString() );
			  
			}
		} return original;
		}
		
	  
		


	private boolean comprobarSiContiene(ArrayList<Integer> numeros, int indice, int valor) {
		for (int i = 0; i < indice; i++) {
            if (numeros.get(i) == valor) {
                return true;
            }
        }
        return false;
	}

}
